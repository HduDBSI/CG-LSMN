package Risk.controller;
import Risk.model.Territory;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class AttackListener implements ActionListener {
    private String attackingTerritory = "";
    private GameFlowController gfController;
    public AttackListener(GameFlowController gfController) {
        this.gfController = gfController;
    }
     @Override
     public void actionPerformed(ActionEvent e) {
         if (selectingAttackingTerritory()) {
             if (clickedOnValidLocation()) {
                 if (!gfController.verifyOwnership(gfController.gui.clickedTerritory)) {
                     return;
                 }

                 attackingTerritory = gfController.gui.clickedTerritory;
             }
         } else if (gfController.phase.equals("attack")) {
             if (clickedOnValidLocation()) {
                 String attack = this.attackingTerritory;
                 this.attackingTerritory = "";
                gfController.initiateCombat(attack, gfController.gui.clickedTerritory, GameFlowController.rand, gfController.gui.attackerDiceSlider.getValue(),
                        gfController.gui.defenderDiceSlider.getValue());
                Territory defendingTerritory = gfController.gbcontroller.getTerritory(gfController.gui.clickedTerritory);
                gfController.gui.setCurrentPlayerArmies(Integer.toString(gfController.playercontroller.getCurrentPlayer().getPlayerArmies()));
                gfController.gui.setCurrentPlayer(String.valueOf(gfController.playercontroller.getCurrentPlayer().getId()));
                gfController.gui.territoryArmiesNumber.setText(String.valueOf(defendingTerritory.getArmyCount()));
                gfController.gui.territoryPlayerNumber.setText(String.valueOf(defendingTerritory.getPlayer()));
            }
         }
     }

     private boolean clickedOnValidLocation() {
         return !(gfController.gui.clickedTerritory.equals(""));
     }

     private boolean selectingAttackingTerritory() {
         return gfController.phase.equals("attack") && attackingTerritory.equals("");
     }

    
          
            
    

          
    
    
  
}