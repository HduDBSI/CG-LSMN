package videorental;
import java.util.List;
public class ReportBuilder {
	public static String getReport(Customer customer) {
		String result = "Customer Report for " + customer.getName() + "\n";
		List<Rental> rentals = customer.getRentals();
		double totalCharge = 0;
 		int totalPoint = 0;

 		for (Rental each : rentals) {

 			int daysRented = each.getDaysRented();

 			double eachCharge = getCharge(each);

 			int eachPoint = getPoint(each);

 			result += "\t" + each.getVideo().getTitle() + "\tDays rented: " + daysRented + "\tCharge: " + eachCharge
 					+ "\tPoint: " + eachPoint + "\n";

 			totalCharge += eachCharge;
			totalPoint += eachPoint;
		}
		result += "Total charge: " + totalCharge + "\tTotal Point:" + totalPoint + "\n";
		if (totalPoint >= 10) {
			System.out.println("Congrat! You earned one free coupon");
		}
		if (totalPoint >= 30) {
			System.out.println("Congrat! You earned two free coupon");
 		}
 		return result;
 	}

 	private static int getPoint(Rental rental) {
 		int rentalPoint = 0;
 		int daysRented = rental.getDaysRented();
 		rentalPoint++;

 		if ((rental.getVideo().getPriceCode() == PriceCode.NEW_RELEASE))
 			rentalPoint++;

 		if (daysRented > rental.getDaysRentedLimit())
 			rentalPoint -= Math.min(rentalPoint, rental.getVideo().getLateReturnPointPenalty());
 		return rentalPoint;
 	}

 	private static double getCharge(Rental rental) {
 		double rentalCharge = 0;
 		int daysRented = rental.getDaysRented();

 		switch (rental.getVideo().getPriceCode()) {
 		case REGULAR:
 			rentalCharge += 2;
 			if (daysRented > 2)
 				rentalCharge += (daysRented - 2) * 1.5;
 			break;
 		case NEW_RELEASE:
 			rentalCharge = daysRented * 3;
 			break;
 		}
 		return rentalCharge;
 	}

 }