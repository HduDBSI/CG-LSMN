package videorental;
import java.util.List;
public class ReportBuilder {
	public static String getReport(Customer customer) {
		String result = "Customer Report for " + customer.getName() + "\n";
		List<Rental> rentals = customer.getRentals();
		double totalCharge = 0;
 		int totalPoint = 0;

 		for (Rental each : rentals) {

 			double eachCharge = each.getCharge();

 			int eachPoint = each.getPoint();

 			result += "\t" + each.getVideo().getTitle() + "\tDays rented: " + each.getDaysRented() + "\tCharge: " + eachCharge
 					+ "\tPoint: " + eachPoint + "\n";

 			totalCharge += eachCharge;
			totalPoint += eachPoint;
		}
		result += "Total charge: " + totalCharge + "\tTotal Point:" + totalPoint + "\n";
		if (totalPoint >= 10) {
			System.out.println("Congrat! You earned one free coupon");
		}
		if (totalPoint >= 30) {
			System.out.println("Congrat! You earned two free coupon");
 		}
 		return result;
 	}

 }