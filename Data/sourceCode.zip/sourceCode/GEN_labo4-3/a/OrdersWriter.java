package ch.heigvd.gen2019;
import java.util.List;
public class OrdersWriter {
    private List<Order> orders;
    public OrdersWriter(List<Order> orders) {
        this.orders = orders;
    }
    public String getContents() {
        StringBuffer sb = new StringBuffer("{\"orders\": [");

         for (int i = 0; i < orders.size(); i++) {
             Order order = orders.get(i);
             getOrderContents(sb, order);
         }

         if (orders.size() > 0) {
            sb.delete(sb.length() - 2, sb.length());
        }
         return sb.append("]}").toString();
     }

     public void getOrderContents(StringBuffer sb, Order order) {
         sb.append("{");
         sb.append("\"id\": ");
         sb.append(order.getOrderId());
         sb.append(", ");
         sb.append("\"products\": [");
         for (int j = 0; j < order.getProductsCount(); j++) {

             order.getProduct(j).getContents(sb);
         }

         if (order.getProductsCount() > 0) {
             sb.delete(sb.length() - 2, sb.length());
         }

         sb.append("]");
         sb.append("}, ");
     }

 }